import numpy as np, wave
from pathlib import Path
sr=48000;dur=45;n=sr*dur;rng=np.random.default_rng(45);out=np.zeros((n,2),dtype=np.float64)
def add(sig,start,pan=0,gain=1):
 k=int(start*sr);m=min(len(sig),n-k)
 if k<0 or m<=0:return
 out[k:k+m,0]+=sig[:m]*gain*np.sqrt((1-pan)/2)
 out[k:k+m,1]+=sig[:m]*gain*np.sqrt((1+pan)/2)
def tone(freq,length,attack=.05,decay=.6):
 t=np.arange(int(sr*length))/sr
 env=np.minimum(t/attack,1)*np.minimum((length-t)/max(.03,length*.25),1)
 return (np.sin(2*np.pi*freq*t)+.23*np.sin(2*np.pi*freq*2*t)+.08*np.sin(2*np.pi*freq*3*t))*env*np.exp(-decay*t)
# D minor / Bb / F / C: original sustained stereo field
for start,root in [(0,50),(5,46),(10,53),(15,48),(21,46),(25,50),(29,46),(33,53),(37,48),(40,50)]:
 length=min(7,45-start)
 for j,semi in enumerate([0,7,12,15,19]):
  f=440*2**((root+semi-69)/12);t=np.arange(int(length*sr))/sr
  env=np.sin(np.pi*np.minimum(t/length,1))**1.4
  sig=(np.sin(2*np.pi*f*t+.03*np.sin(2*np.pi*.3*t))+np.sin(2*np.pi*(f*1.002)*t))/2
  add(sig*env,start,pan=(j-2)*.32,gain=.045 if start<25 else .06)
# heartbeat / sub impacts on chapter changes
for start in [0,4.5,10,15,21,25,32,39]:
 t=np.arange(int(1.8*sr))/sr;sig=np.sin(2*np.pi*(38*t+48*(1-np.exp(-t*9))/9))*np.exp(-t*4)
 add(sig,start,0,.32)
# accelerating arpeggio, spacious stereo echoes
notes=[62,69,74,77,81,77,74,69]
for i,start in enumerate(np.arange(4.5,39,.25)):
 if 21<=start<25:continue
 f=440*2**((notes[i%8]-69)/12);sig=tone(f,.72,.008,7)
 gain=.038 if start<10 else (.07 if start>=25 else .055)
 add(sig,start,.6*np.sin(i*1.7),gain)
 add(sig,start+.375,-.6*np.sin(i*1.7),gain*.30)
# dry electronic pulse and high hat
for i,start in enumerate(np.arange(10,39,.5)):
 if 21<=start<25:continue
 t=np.arange(int(.35*sr))/sr
 add(np.sin(2*np.pi*(46*t+30*(1-np.exp(-t*30))/30))*np.exp(-t*17),start,0,.14)
 if i%2:
  noise=rng.normal(0,1,int(sr*.10)); noise=np.concatenate([[0],np.diff(noise)])
  add(noise*np.exp(-np.arange(len(noise))/sr*65),start,.35*(-1)**i,.014)
# broadband whooshes, softened moving noise with a rising oscillator
for start in [3.7,9.2,14.2,24.1,31.1,38.1]:
 t=np.arange(int(sr*.8))/sr;noise=rng.normal(0,1,len(t));noise=np.convolve(noise,np.ones(16)/16,mode='same')
 env=np.sin(np.pi*t/.8)**2
 add((noise*.23+np.sin(2*np.pi*(150*t+600*t*t))*.07)*env,start,-.2,.22)
# last bell and low ambient tail
for semi,g in [(74,.10),(81,.055),(86,.03)]:add(tone(440*2**((semi-69)/12),5,.03,.8),39.6,.15,g)
t=np.arange(n)/sr;master=np.minimum(t/.8,1)*np.minimum((45-t)/1.5,1)
out=np.tanh(out*1.3)*master[:,None]
peak=np.max(np.abs(out));out=out*1.7
out=out*(.88/max(np.max(np.abs(out)),.88))
with wave.open('/workspace/ai-evolution/assets/Original-Score.wav','wb') as f:
 f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((out*32767).astype('<i2').tobytes())
print('45s original score, peak',float(np.max(np.abs(out))))
