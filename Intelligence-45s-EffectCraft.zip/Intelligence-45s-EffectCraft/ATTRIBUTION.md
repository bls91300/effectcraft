# Asset credits

- Original-Score.wav — Original procedural music and sound design created for this film, 2026-10-20; no external samples; MIT OR Apache-2.0.
- Native vector artwork, chapter text and generated JSX — original work created for this film; MIT OR Apache-2.0.
- NanumGothic — NAVER Corporation / Sandoll contributors; SIL Open Font License 1.1; included font, https://github.com/google/fonts/tree/main/ofl/nanumgothic
- Inter — Rasmus Andersson and contributors; SIL Open Font License 1.1; bundled with EffectCraft, https://github.com/rsms/inter
- JetBrains Mono — JetBrains and contributors; SIL Open Font License 1.1; bundled with EffectCraft, https://github.com/JetBrains/JetBrainsMono

The research README copies in sources/ are evidence notes, not assets in the film and are not included in the project delivery bundle. Their respective authors retain their rights.
