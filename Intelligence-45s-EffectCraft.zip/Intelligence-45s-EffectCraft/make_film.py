from pathlib import Path
import json, math, random
P=Path('/workspace/ai-evolution'); random.seed(27)
lines=['app.beginUndoGroup("Intelligence / 45 seconds");','var c=app.project.items.addComp("지능의 시간 | 1956—2046",1920,1080,1,45,24); c.bgColor=[0.012,0.023,0.043];']
def js(x): return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def emit(s): lines.append(s)
def rgb(h): return [round(int(h[i:i+2],16)/255,5) for i in (0,2,4)]
WHITE='EDF4F7'; MUTED='8297AC'; CYAN='65E8E3'; BLUE='417DFF'; AMBER='F8BE73'; VIOLET='B6A2FF'; DARK='111F32'
count=0
def layer(name,a=0,b=45,pos=(0,0),opacity=100):
 global count
 count+=1; v='L'+str(count)
 emit(f'var {v}=c.layers.addShape(); {v}.name={js(name)}; {v}.transform.position.setValue({js(pos)}); {v}.inPoint={a}; {v}.outPoint={b}; {v}.transform.opacity.setValue({opacity});')
 return v

def path(l,pts,col,width=2,closed=False,fill=False,op=100):
 emit(f'var g={l}.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group").property("ADBE Vectors Group");var p=g.addProperty("ADBE Vector Shape - Group");var s=new Shape();s.vertices={js(pts)};s.closed={str(closed).lower()};p.property("ADBE Vector Shape").setValue(s);')
 kind='Fill' if fill else 'Stroke'; emit(f'var f=g.addProperty("ADBE Vector Graphic - {kind}");f.property("ADBE Vector {kind} Color").setValue({js(rgb(col))});f.property("ADBE Vector {kind} Opacity").setValue({op});')
 if not fill: emit(f'f.property("ADBE Vector Stroke Width").setValue({width});')
def rect(l,x,y,w,h,col,op=100): path(l,[[x,y],[x+w,y],[x+w,y+h],[x,y+h]],col,closed=True,fill=True,op=op)
def circle(l,x,y,r,col,width=2,fill=False,op=100,ratio=1):
 pts=[[round(x+r*math.cos(i*math.tau/80),2),round(y+ratio*r*math.sin(i*math.tau/80),2)] for i in range(80)]
 path(l,pts,col,width,True,fill,op)
def key(v,prop,keys,ease=False):
 for t,val in keys: emit(f'{v}.transform.{prop}.setValueAtTime({round(t,5)},{js(val)});')
 if ease:
  emit(f'for(var k=1;k<={v}.transform.{prop}.numKeys;k++){{{v}.transform.{prop}.setTemporalEaseAtKey(k,[new KeyframeEase(0,65)],[new KeyframeEase(0,65)]);}}')
def appear(v,a,b,op=100,move=None):
 key(v,'opacity',[(a,0),(a+.38,op),(b-.30,op),(b,0)])
 if move:
  x,y=move; key(v,'position',[(a,[x,y+32]),(a+.7,[x,y]),(b-.3,[x,y]),(b,[x,y-12])],True)
def txt(text,x,y,size,a,b,color=WHITE,font='NanumGothic',style='Regular',fade=True,tracking=0):
 global count
 count+=1;v='L'+str(count)
 emit(f'var d=new TextDocument({js(text)});d.font={js(font)};d.fontSize={size};d.fillColor={js(rgb(color))};d.justification=ParagraphJustification.LEFT_JUSTIFY;d.tracking={tracking};d.fontStyle={js(style)};var {v}=c.layers.addText(d);{v}.name={js(text[:38])};{v}.transform.anchorPoint.setValue([0,0]);{v}.transform.position.setValue([{x},{y}]);{v}.inPoint={a};{v}.outPoint={b};')
 if fade: appear(v,a,b,move=(x,y))
 return v

def label(s,a,b,color=CYAN): txt(s,128,188,22,a,b,color,'JetBrains Mono',tracking=120)
def headline(s,a,b,color=WHITE,size=86,y=372): return txt(s,122,y,size,a+.12,b,color,style='Bold')
def sub(s,a,b,y=465): return txt(s,128,y,31,a+.35,b,MUTED)
def note(s,a,b): txt(s,128,891,21,a+.3,b,MUTED)

# Persistent art direction: dark observatory, inset grid, star map, fine registration.
grid=layer('Observatory / grid',opacity=38)
for x in range(120,1860,120): path(grid,[[x,230],[x,828]],'243447',1)
for y in range(230,850,100): path(grid,[[120,y],[1800,y]],'243447',1)
# glowing circular atmosphere through low-opacity concentric bands
halo=layer('Field / concentric atmosphere',pos=(1430,515))
for r in range(370,90,-20): circle(halo,0,0,r,BLUE,24,op=1.8)
key(halo,'scale',[(0,[80,80]),(15,[110,110]),(25,[95,95]),(39,[122,122]),(45,[100,100])],True)
stars=layer('Distant points',opacity=42)
for _ in range(65):
 x=random.randint(130,1790);y=random.randint(240,820);circle(stars,x,y,random.choice([1,1,1.5]),MUTED,fill=True)
# top chrome, timeline
chrome=layer('Frame / rules')
path(chrome,[[128,116],[1792,116]],'33465B',1)
path(chrome,[[128,948],[1792,948]],'33465B',2)
for x in [128,544,960,1376,1792]: path(chrome,[[x,942],[x,957]],MUTED,2)
for x,y in [(105,100),(1815,100),(105,918),(1815,918)]:
 path(chrome,[[x-7,y],[x+7,y]],MUTED,1);path(chrome,[[x,y-7],[x,y+7]],MUTED,1)
txt('INTELLIGENCE / A BRIEF HISTORY OF TOMORROW',128,88,18,0,45,MUTED,'JetBrains Mono',fade=False,tracking=80)
txt('45 SECONDS     /     EFFECTCRAFT',1390,88,18,0,45,MUTED,'JetBrains Mono',fade=False)
for s,x in [('1956',128),('2017',520),('2026',932),('2036',1348),('2046',1735)]: txt(s,x,988,19,0,45,MUTED,'JetBrains Mono',fade=False)
progress=layer('Time / playhead')
rect(progress,0,0,1664,3,CYAN);key(progress,'scale',[(0,[0,100]),(45,[100,100])]);progress_pos=[128,947];emit(f'{progress}.transform.position.setValue({js(progress_pos)});')
# central orbit art recurring through eras
orb=layer('Intelligence / evolving orbital instrument',0,45,(1430,520))
for r,ratio,angle in [(260,.48,0),(260,.48,60),(260,.48,120),(286,1,0)]:
 pts=[]
 for i in range(120):
  u=i*math.tau/120; xx=r*math.cos(u);yy=r*ratio*math.sin(u);q=math.radians(angle);pts.append([round(xx*math.cos(q)-yy*math.sin(q),2),round(xx*math.sin(q)+yy*math.cos(q),2)])
 path(orb,pts,CYAN if ratio<1 else BLUE,1.6,True,False,38 if ratio<1 else 28)
for i in range(72):
 u=i*math.tau/72;r=305;le=14 if i%6==0 else 5
 path(orb,[[r*math.cos(u),r*math.sin(u)],[(r+le)*math.cos(u),(r+le)*math.sin(u)]],CYAN,1.5,op=48)
key(orb,'rotation',[(0,-30),(45,70)])
key(orb,'scale',[(0,[35,35]),(4,[88,88]),(10,[78,78]),(15,[100,100]),(21,[112,112]),(25,[65,65]),(32,[95,95]),(39,[112,112]),(45,[78,78])],True)
key(orb,'opacity',[(0,0),(1.8,72),(21,72),(22,18),(25,18),(26,65),(39,65),(40,28),(45,28)])
# 00—04.5 / hook
label('00 / THE QUESTION',0,4.5)
headline('지능의 시간',0,4.5,size=108,y=401)
sub('우리는 무엇을 만들고 있는가.',0,4.5,y=491)
txt('PAST  /  PRESENT  /  POSSIBLE FUTURES',128,620,20,.8,4.5,CYAN,'JetBrains Mono',tracking=120)
core=layer('The first pulse',0,4.5,(1430,520));circle(core,0,0,38,CYAN,fill=True)
key(core,'scale',[(0,[0,0]),(.7,[12,12]),(2.6,[120,120]),(4.5,[38,38])],True);appear(core,0,4.5)
note('1956 — 2046  /  인공지능의 과거와 가능한 미래',0,4.5)
# 4.5—10 / past, accelerated timeline
label('01 / ORIGINS',4.5,10,AMBER)
headline('규칙에서, 학습으로.',4.5,10,size=78)
sub('사람이 답을 쓰던 기계가',4.5,10)
sub('데이터에서 패턴을 배우기 시작했다.',4.7,10,y=513)
for i,(yr,desc) in enumerate([('1956','AI 연구의 출발'),('2012','딥러닝의 도약'),('2017','Transformer'),('2022','대화형 AI 대중화')]):
 a=4.7+i*.55
 txt(yr,128+i*215,676,52,a,10,AMBER,'Inter',style='Bold')
 txt(desc,128+i*215,722,23,a+.1,10,MUTED)
net=layer('Learning / sparse graph',4.5,10,(1430,520))
pts=[[-170,-130],[-170,0],[-170,130],[0,-170],[0,-55],[0,60],[0,175],[170,-100],[170,100]]
for i,p in enumerate(pts):
 for j,q in enumerate(pts):
  if q[0]>p[0] and q[0]-p[0]<180:path(net,[p,q],AMBER,1.5,op=32)
for x,y in pts:circle(net,x,y,7,AMBER,fill=True)
appear(net,4.5,10);key(net,'scale',[(4.5,[65,65]),(10,[110,110])],True)
note('역사적 이정표  /  연구의 진보는 곧바로 범용 지능을 뜻하지 않는다.',4.5,10)
# 10—15 / recent period overview
label('02 / ACCELERATION   2024.10—2026.10',10,15)
headline('답변을 넘어,',10,15,size=90)
headline('추론과 실행으로.',10,15,size=90,y=482,color=CYAN)
sub('코드 · 도구 사용 · 과학 연구로 넓어지는 가능성',10.3,15,y=594)
for i,(s,y) in enumerate([('REASON',370),('BUILD',510),('DISCOVER',650)]):
 v=txt(s,1210,y,53,10.2+i*.3,15,CYAN,'Inter',style='Bold',tracking=120)
 key(v,'position',[(10.2+i*.3,[1280,y+25]),(11.3+i*.3,[1210,y]),(15,[1160,y])],True)
note('공개 근거: 2024–2025 자료 중심  /  DeepSeek-R1 · SWE-bench · AlphaFold 3',10,15)
# 15—21 / one honest numeric comparison
label('03 / MEASURED PROGRESS',15,21)
headline('도약은 숫자로도 보인다.',15,21,size=72)
sub('GPQA 정답률 · 특정 모델 비교',15,21,y=455)
txt('46.0',125,653,128,15.4,21,WHITE,'Inter',style='Bold')
txt('→',500,638,75,15.7,21,MUTED)
txt('66.3',640,653,128,15.9,21,CYAN,'Inter',style='Bold')
txt('%',970,650,48,16.1,21,CYAN,'Inter')
txt('GPT-4o / 2024.11',130,708,22,15.4,21,MUTED,'JetBrains Mono')
txt('GPT-4.1 / 2025.04',650,708,22,15.9,21,MUTED,'JetBrains Mono')
bar=layer('Measured gain / two bars',15,21,(1190,705));rect(bar,0,-230,150,230,WHITE);rect(bar,220,-331.5,150,331.5,CYAN)
key(bar,'scale',[(15,[100,0]),(16.6,[100,100])],True);appear(bar,15,21)
note('출처: OpenAI simple-evals  /  평가 조건에 한정된 결과이며, 전체 지능의 척도는 아니다.',15,21)
# 21—25 / reality brake
label('04 / THE FRICTION',21,25,AMBER)
headline('성능 ≠ 신뢰',21,25,size=104,color=AMBER,y=420)
sub('오류, 전력, 검증, 책임.',21,25,y=517)
sub('현실의 속도는 데모보다 느리다.',21.2,25,y=565)
warn=layer('Reality / interrupted signal',21,25,(1430,520))
path(warn,[[-160,130],[0,-150],[160,130]],AMBER,4,True)
path(warn,[[0,-50],[0,45]],AMBER,9);circle(warn,0,80,6,AMBER,fill=True);appear(warn,21,25)
note('확산의 병목  /  신뢰성 · 비용 · 규제 · 조직의 변화',21,25)
# 25—32 / plausible ten-year scenario
label('05 / 2036   +10 YEARS   /   SCENARIO',25,32,VIOLET)
headline('작업을 맡기는 시대',25,32,size=84)
sub('AI 에이전트가 연결된 업무를 수행하고,',25,32,y=466)
sub('사람은 목표·검증·책임을 맡는다.',25.2,32,y=515)
for i,(word,desc) in enumerate([('위임','계획 · 도구 · 실행'),('검증','평가 · 보안 · 승인')]):
 txt(word,128+i*350,676,47,25.5+i*.3,32,VIOLET,style='Bold')
 txt(desc,128+i*350,724,24,25.7+i*.3,32,MUTED)
# a coordinated orbital network with moving packets
network=layer('2036 / coordinated agents',25,32,(1430,520));circle(network,0,0,52,VIOLET,3)
for i in range(6):
 u=i*math.tau/6;x=220*math.cos(u);y=220*math.sin(u)
 path(network,[[0,0],[x,y]],VIOLET,2,op=55);circle(network,x,y,25,VIOLET,2)
 v=layer('2036 / task packet '+str(i),25,32,(1430,520));circle(v,0,0,5,WHITE,fill=True)
 keys=[]
 for j in range(8):
  t=25+j;f=((j+i)%4)/3;keys.append((t,[1430+x*f,520+y*f]))
 key(v,'position',keys);appear(v,25,32)
appear(network,25,32);key(network,'rotation',[(25,-12),(32,12)])
note('조건부 전망  /  신뢰성 개선·비용 하락·현장 통합이 지속될 경우',25,32)
# 32—39 / 20 year horizon as infrastructure, no promised AGI
label('06 / 2046   +20 YEARS   /   SCENARIO',32,39,VIOLET)
headline('지능이 인프라가 된다면',32,39,size=76)
sub('맞춤 교육, 연구 가속, 일부 현장 자동화.',32,39,y=465)
sub('혜택의 크기는 에너지와 제도, 접근성에 달렸다.',32.2,39,y=515)
txt('가능성은 커지고,',128,677,43,32.6,39,VIOLET,style='Bold')
txt('불확실성도 커진다.',128,737,43,32.8,39,WHITE,style='Bold')
city=layer('2046 / civic intelligence',32,39,(1430,600))
for i in range(11):
 x=-260+i*50;h=random.randint(90,260)
 path(city,[[x,90],[x,-h],[x+30,-h],[x+30,90]],VIOLET,2,op=70)
 for y in range(-h+20,75,28):path(city,[[x+8,y],[x+21,y]],CYAN,2,op=65)
path(city,[[-300,92],[310,92]],VIOLET,2)
for r in [110,180,250]:
 pts=[[r*math.cos(u),-250+.33*r*math.sin(u)] for u in [j*math.pi/50 for j in range(101)]];path(city,pts,CYAN,2,op=55)
appear(city,32,39);key(city,'scale',[(32,[88,88]),(39,[110,110])],True)
note('장기 시나리오  /  완전 자율화·범용 지능의 실현 시점은 확정할 수 없다.',32,39)
# 39—45 / human choice, visual resolution
label('07 / THE HUMAN VARIABLE',39,45,CYAN)
headline('미래를 정하는 것은',39,45,size=84,y=382)
headline('성능만이 아니다.',39,45,size=93,y=497,color=CYAN)
sub('무엇을 맡기고, 무엇을 지킬 것인가.',39.6,45,y=610)
txt('THE NEXT CHAPTER IS A CHOICE.',128,760,23,40.6,45,WHITE,'JetBrains Mono',tracking=130)
final=layer('Human / horizon',39,45,(1430,520));circle(final,0,0,105,CYAN,2)
circle(final,0,-12,20,WHITE,2);path(final,[[-42,58],[-30,23],[30,23],[42,58]],WHITE,3)
for r in [160,205,250]: circle(final,0,0,r,CYAN,1,op=25)
appear(final,39,45);key(final,'scale',[(39,[80,80]),(44,[108,108])],True)
note('근거와 시나리오를 구분한 45초  /  상세 자료: 동봉한 SOURCES.md',39,45)
# opening and closing black fade, no hard end
black=c=None
emit('var end=c.layers.addSolid([0,0,0],"End / fade",1920,1080,1);end.inPoint=44.25;end.outPoint=45;end.transform.opacity.setValueAtTime(44.25,0);end.transform.opacity.setValueAtTime(45,100);')
emit('var start=c.layers.addSolid([0,0,0],"Start / fade",1920,1080,1);start.inPoint=0;start.outPoint=.5;start.transform.opacity.setValueAtTime(0,100);start.transform.opacity.setValueAtTime(.5,0);')
emit('c.time=2;app.endUndoGroup(); app.project.save(new File("/workspace/ai-evolution/Intelligence-45s.ecproj"));writeLn("Built "+c.numLayers+" layers / 45 seconds / 24 fps");')
(P/'build.jsx').write_text('\n'.join(lines))
print('JSX operations',len(lines),'layers',count)
