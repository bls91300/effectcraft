# 지능의 시간 — EffectCraft 편집 프로젝트

45초 / 1920×1080 / 24fps. 한국어 키네틱 타이포그래피와 벡터 애니메이션, 오리지널 음악.
화면의 미래는 2026년을 기준으로 한 2036년·2046년 조건부 시나리오입니다.
사실 확인 범위와 참고 자료는 SOURCES.md에 있습니다.

## 열기

1. ZIP을 폴더에 압축 해제합니다.
2. `Fonts/`의 TTF 글꼴을 설치하거나, EffectCraft를 실행할 때 `EFFECTCRAFT_FONT_DIRS`를 해당 폴더의 절대 경로로 지정합니다.
3. EffectCraft 0.13.0에서 `Intelligence-45s.ecproj`를 엽니다.
4. 음악은 `(Footage)/Original-Score.wav`에 있으며 프로젝트에서 상대 경로로 연결됩니다.

CLI 예시 (Linux/macOS, 이 폴더에서 실행):

```bash
export EFFECTCRAFT_FONT_DIRS="$PWD/Fonts"
effectcraft-cli render-frame Intelligence-45s.ecproj --time 17.5 --out preview.png
effectcraft-cli render Intelligence-45s.ecproj --fps 24 --bitrate 10000 --audio on --out Intelligence-45s.mp4
```

화면 레이어·글자·키프레임을 직접 편집할 수 있습니다. 2036·2046년 네트워크와 도시도 네이티브 벡터입니다.
음악은 외부 샘플 없이 파형으로 제작했으며 나레이션은 없습니다.

## 제작 스크립트

`make_film.py`, `build.jsx`, `score.py`는 제작에 사용한 소스입니다.
원래 클라우드 경로 `/workspace/ai-evolution`을 사용하므로 다른 환경에서 재생성하려면 해당 경로를 작업 폴더로 바꾸세요.
`make_film.py`가 JSX를 생성하고 EffectCraft의 `script` 명령이 프로젝트를 생성합니다.
`score.py`가 WAV를 생성합니다. 재생성한 프로젝트에는 음악을 다시 가져와야 합니다.
기존 `.ecproj`를 열어 편집하거나 위 CLI 명령으로 재렌더링할 때에는 이 스크립트들을 실행할 필요가 없습니다.

글꼴과 원본 음악의 권리는 ATTRIBUTION.md 및 Fonts/의 라이선스를 확인하세요.
